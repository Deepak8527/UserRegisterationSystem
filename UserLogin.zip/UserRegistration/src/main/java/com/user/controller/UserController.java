package com.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.user.model.User;
import com.user.service.UserService;
import org.springframework.ui.Model; 

@Controller
public class UserController {
  @Autowired
  private UserService userService;

  @GetMapping("/register")
  public String showRegisteration(Model model) {
    model.addAttribute("user" , new User());
    return "register";
  }
   @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") User user, Model model) {
        if (userService.findByEmail(user.getEmail()) != null) {
            model.addAttribute("message", "User with this email already exists.");
            return "register";
        }
        userService.saveUser(user);
        model.addAttribute("message", "User registered successfully!");
        return "register";
    }
  
}
